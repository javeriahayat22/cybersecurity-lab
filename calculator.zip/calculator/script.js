let current = '0';
let previous = null;
let operator = null;
let justCalculated = false;
let lastOperand = '';

const currentEl = document.getElementById('current');
const historyEl = document.getElementById('history');

function updateDisplay() {
  currentEl.textContent = current;
  if (justCalculated && previous !== null && operator) {
    historyEl.textContent = `${previous} ${operator} ${lastOperand} =`;
  } else if (previous !== null && operator) {
    historyEl.textContent = `${previous} ${operator}`;
  } else {
    historyEl.textContent = '\u00A0';
  }
}

function inputDigit(d) {
  if (justCalculated) {
    current = d;
    justCalculated = false;
  } else {
    current = current === '0' ? d : current + d;
  }
  updateDisplay();
}

function inputDot() {
  if (justCalculated) {
    current = '0.';
    justCalculated = false;
  } else if (!current.includes('.')) {
    current += '.';
  }
  updateDisplay();
}

function clearAll() {
  current = '0';
  previous = null;
  operator = null;
  justCalculated = false;
  updateDisplay();
}

function backspace() {
  if (justCalculated) return;
  current = current.length > 1 ? current.slice(0, -1) : '0';
  updateDisplay();
}

function percent() {
  current = String(parseFloat(current) / 100);
  updateDisplay();
}

function chooseOp(op) {
  if (operator && previous !== null && !justCalculated) {
    calculate();
  }
  previous = current;
  operator = op;
  justCalculated = false;
  current = '0';
  updateDisplay();
}

function compute(a, b, op) {
  a = parseFloat(a);
  b = parseFloat(b);
  switch (op) {
    case '+': return a + b;
    case '−': return a - b;
    case '×': return a * b;
    case '÷': return b === 0 ? 'Error' : a / b;
    default: return b;
  }
}

function calculate() {
  if (operator === null || previous === null) return;
  const result = compute(previous, current, operator);
  lastOperand = current;
  const usedPrevious = previous;
  const usedOperator = operator;
  current = String(result);
  previous = null;
  operator = null;
  justCalculated = true;
  currentEl.textContent = current;
  historyEl.textContent = `${usedPrevious} ${usedOperator} ${lastOperand} =`;
}

// Keyboard support
document.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') inputDigit(e.key);
  else if (e.key === '.') inputDot();
  else if (e.key === '+') chooseOp('+');
  else if (e.key === '-') chooseOp('−');
  else if (e.key === '*') chooseOp('×');
  else if (e.key === '/') { e.preventDefault(); chooseOp('÷'); }
  else if (e.key === 'Enter' || e.key === '=') calculate();
  else if (e.key === 'Backspace') backspace();
  else if (e.key === 'Escape') clearAll();
});