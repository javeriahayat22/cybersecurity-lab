function showMessage() {
    alert("Thank you for your interest! Please contact me for job opportunities.");
}

const navLinks = document.querySelectorAll("nav a");

navLinks.forEach(function(link) {
    link.addEventListener("click", function() {
        console.log("Navigation link clicked");
    });
});